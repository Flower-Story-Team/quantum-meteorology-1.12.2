package com.konpi.flowerofhua.flower.capabilities;
/*
去看flowerplayerP。
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class CapabilitiesManager {
    private static final ResourceLocation adventPlayer = new ResourceLocation("flower", "FlowerPlayer");

    @SubscribeEvent
    public void attachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof EntityPlayerMP)
            event.addCapability(adventPlayer, new FlowerPlayerProvider((EntityPlayer)event.getObject()));
    }
}

 */