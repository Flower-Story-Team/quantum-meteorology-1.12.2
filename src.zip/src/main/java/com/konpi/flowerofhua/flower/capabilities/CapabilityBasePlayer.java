package com.konpi.flowerofhua.flower.capabilities;
/*
import net.minecraft.entity.player.EntityPlayer;

public interface CapabilityBasePlayer {
    public void init(EntityPlayer pl);

    public PlayerDataManager getPlayerData();
}

 */