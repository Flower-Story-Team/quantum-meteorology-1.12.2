package com.konpi.flowerofhua.flower.capabilities;
/* 特性在这
*https://github.com/Tslat/Advent-Of-Ascension/blob/master/source/utils/player/PlayerDataManager.java
* 这是虚无的链接请去参考
* 先做框架
public class PlayerDataManager {
}

 */
