package com.konpi.flowerofhua.flower.item;

import net.minecraft.item.ItemFood;

public class CoarseSalt extends ItemFood {
    public CoarseSalt() {
        super(1, 2, false);
    }
}
